import * as THREE from '../three.js-master/build/three.module.js'
import * as THREE_Font from '../three.js-master/examples/jsm/loaders/FontLoader.js'
import * as THREE_TextGeo from '../three.js-master/examples/jsm/geometries/TextGeometry.js'
import { OrbitControls } from '../three.js-master/examples/jsm/controls/OrbitControls.js'

let w = window.innerWidth;
let h = window.innerHeight;
let aspect = w / h;
let scene = new THREE.Scene();

let camera = new THREE.PerspectiveCamera(45, aspect, 0.1, 1000);
camera.position.set(0, 0, 128);
camera.lookAt(new THREE.Vector3(0, 0, 0));

let renderer = new THREE.WebGLRenderer({ antialias: true });
renderer.setSize(w, h);
renderer.setClearColor(0xf1f1f1);
renderer.shadowMap.type = THREE.PCFShadowMap;
renderer.shadowMap.enabled = true;

let control = new OrbitControls(camera, renderer.domElement);

document.body.appendChild(renderer.domElement);

function Sun() {
    const SunGeo = new THREE.SphereGeometry(10);
    const SunText = new THREE.TextureLoader().load("./assets/planet/sun.jpeg");
    const SunMat = new THREE.MeshBasicMaterial({ map: SunText });
    const SunMesh = new THREE.Mesh(SunGeo, SunMat);
    SunMesh.receiveShadow = true;
    SunMesh.name = "sun"
    SunMesh.position.set(-20, 0, 0)
    scene.add(SunMesh);

    let loader = new THREE_Font.FontLoader()
    loader.load('../fonts/Roboto_Regular.json', function(font) {
        const geoH1 = new THREE_TextGeo.TextGeometry(
            'Sun ', {
                font: font,
                size: 3,
                height: 2,
            }
        )

        let textMeshH1 = new THREE.Mesh(geoH1, [
            new THREE.MeshPhongMaterial({ color: 0x000000 }),
            new THREE.MeshPhongMaterial({ color: 0x808080 })
        ])

        textMeshH1.castShadow = true
        textMeshH1.position.y = SunMesh.position.y
        textMeshH1.position.z = SunMesh.position.z
        textMeshH1.position.x = SunMesh.position.x + 10
        scene.add(textMeshH1)

        const geoP = new THREE_TextGeo.TextGeometry(
            "1. Matahari merupakan sebuah bintang karena dapat menghasilkan cahaya nya sendiri.\n2. 99,86% massa Tata Surya berasal dari Matahari. Sisanya merupakan massa gabungan dari 8 planet dan asteroid di Tata Surya.\n3. Bola gas berbentuk plasma yang sangat panas.\n4. Cuaca dan iklim di Bumi akan tergantung dari angin Sang Surya Matahari. \n 5. Matahari hanyalah 1 dari triliunan bintang di alam semesta. \n 6. Diamater Matahari setara 109 kali diameter Bumi.", {
                font: font,
                size: 1,
                height: 1,
            }
        )

        let textMeshP = new THREE.Mesh(geoP, [
            new THREE.MeshPhongMaterial({ color: 0x000000 }),
            new THREE.MeshPhongMaterial({ color: 0x808080 })
        ])

        textMeshP.castShadow = true
        textMeshP.position.y = SunMesh.position.y - 5
        textMeshP.position.z = SunMesh.position.z
        textMeshP.position.x = SunMesh.position.x + 10
        scene.add(textMeshP)
    })
}

function CreateLight() {
    const light = new THREE.AmbientLight(0xFFFFFF, 1);
    scene.add(light);
}

function animate() {
    requestAnimationFrame(animate);
    control.update();
    renderer.render(scene, camera);
}

window.onload = () => {
    Sun();
    CreateLight();
    //PlanetListener(); //gk bisa
    animate();
}