import * as THREE from '../three.js-master/build/three.module.js'
import * as THREE_Font from '../three.js-master/examples/jsm/loaders/FontLoader.js'
import * as THREE_TextGeo from '../three.js-master/examples/jsm/geometries/TextGeometry.js'
import { OrbitControls } from '../three.js-master/examples/jsm/controls/OrbitControls.js'

let w = window.innerWidth;
let h = window.innerHeight;
let aspect = w / h;
let scene = new THREE.Scene();

let camera = new THREE.PerspectiveCamera(45, aspect, 0.1, 1000);
camera.position.set(0, 0, 128);
camera.lookAt(new THREE.Vector3(0, 0, 0));

let renderer = new THREE.WebGLRenderer({ antialias: true });
renderer.setSize(w, h);
renderer.setClearColor(0xf1f1f1);
renderer.shadowMap.type = THREE.PCFShadowMap;
renderer.shadowMap.enabled = true;

let control = new OrbitControls(camera, renderer.domElement);

document.body.appendChild(renderer.domElement);

function Neptune() {
    const NeptuneGeo = new THREE.SphereGeometry(4);
    const NeptuneText = new THREE.TextureLoader().load("./assets/planet/neptune.jpeg");
    const NeptuneMat = new THREE.MeshBasicMaterial({ map: NeptuneText });
    const NeptuneMesh = new THREE.Mesh(NeptuneGeo, NeptuneMat);
    NeptuneMesh.receiveShadow = true;
    NeptuneMesh.name = "neptune"
    NeptuneMesh.position.set(-20, 0, 0)
    scene.add(NeptuneMesh);

    let loader = new THREE_Font.FontLoader()
    loader.load('../fonts/Roboto_Regular.json', function(font) {
        const geoH1 = new THREE_TextGeo.TextGeometry(
            'Planet Neptune ', {
                font: font,
                size: 3,
                height: 2,
            }
        )

        let textMeshH1 = new THREE.Mesh(geoH1, [
            new THREE.MeshPhongMaterial({ color: 0x000000 }),
            new THREE.MeshPhongMaterial({ color: 0x808080 })
        ])

        textMeshH1.castShadow = true
        textMeshH1.position.y = NeptuneMesh.position.y
        textMeshH1.position.z = NeptuneMesh.position.z
        textMeshH1.position.x = NeptuneMesh.position.x + 10
        scene.add(textMeshH1)

        const geoP = new THREE_TextGeo.TextGeometry(
            "1. Planet neptunus ditemukan secara tidak sengaja dan sangat sulit untuk ditemukan pada malam hari.\n2. Planet yang memiliki usia yang sama dengan matahari.\n3. Planet paling jauh dan paling lambat diantara planet lainnya.\n4. Planet dengan badai menakutkan yang berukuran sebesar bumi dengan kecepatan angin 1.340 km per detik", {
                font: font,
                size: 1,
                height: 1,
            }
        )

        let textMeshP = new THREE.Mesh(geoP, [
            new THREE.MeshPhongMaterial({ color: 0x000000 }),
            new THREE.MeshPhongMaterial({ color: 0x808080 })
        ])

        textMeshP.castShadow = true
        textMeshP.position.y = NeptuneMesh.position.y - 5
        textMeshP.position.z = NeptuneMesh.position.z
        textMeshP.position.x = NeptuneMesh.position.x + 10
        scene.add(textMeshP)
    })
}

function CreateLight() {
    const light = new THREE.AmbientLight(0xFFFFFF, 1);
    scene.add(light);
}

function animate() {
    requestAnimationFrame(animate);
    control.update();
    renderer.render(scene, camera);
}

window.onload = () => {
    Neptune();
    CreateLight();
    //PlanetListener(); //gk bisa
    animate();
}