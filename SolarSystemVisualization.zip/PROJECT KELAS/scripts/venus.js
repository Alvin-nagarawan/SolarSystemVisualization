import * as THREE from '../three.js-master/build/three.module.js'
import * as THREE_Font from '../three.js-master/examples/jsm/loaders/FontLoader.js'
import * as THREE_TextGeo from '../three.js-master/examples/jsm/geometries/TextGeometry.js'
import { OrbitControls } from '../three.js-master/examples/jsm/controls/OrbitControls.js'

let w = window.innerWidth;
let h = window.innerHeight;
let aspect = w / h;
let scene = new THREE.Scene();

let camera = new THREE.PerspectiveCamera(45, aspect, 0.1, 1000);
camera.position.set(0, 0, 128);
camera.lookAt(new THREE.Vector3(0, 0, 0));

let renderer = new THREE.WebGLRenderer({ antialias: true });
renderer.setSize(w, h);
renderer.setClearColor(0xf1f1f1);
renderer.shadowMap.type = THREE.PCFShadowMap;
renderer.shadowMap.enabled = true;

let control = new OrbitControls(camera, renderer.domElement);


document.body.appendChild(renderer.domElement);

function Venus() {
    const VenusGeo = new THREE.SphereGeometry(3.5);
    const VenusText = new THREE.TextureLoader().load("./assets/planet/venus.jpeg");
    const VenusMat = new THREE.MeshBasicMaterial({ map: VenusText });
    const VenusMesh = new THREE.Mesh(VenusGeo, VenusMat);
    VenusMesh.position.x = 32;
    VenusMesh.name = "venus"
    VenusMesh.receiveShadow = true;
    VenusMesh.position.set(-20, 0, 0)
    scene.add(VenusMesh);

    let loader = new THREE_Font.FontLoader()
    loader.load('../fonts/Roboto_Regular.json', function(font) {
        const geoH1 = new THREE_TextGeo.TextGeometry(
            'Planet Venus ', {
                font: font,
                size: 3,
                height: 2,
            }
        )

        let textMeshH1 = new THREE.Mesh(geoH1, [
            new THREE.MeshPhongMaterial({ color: 0x000000 }),
            new THREE.MeshPhongMaterial({ color: 0x808080 })
        ])

        textMeshH1.castShadow = true
        textMeshH1.position.y = VenusMesh.position.y
        textMeshH1.position.z = VenusMesh.position.z
        textMeshH1.position.x = VenusMesh.position.x + 10
        scene.add(textMeshH1)

        const geoP = new THREE_TextGeo.TextGeometry(
            "1. Planet terpanas di Tata Surya meskipun berada di urutan kedua dalam jajaran Tata Surya. Temperaturnya bisa mencapai 471 derajat celcius\n2. Satu hari lebih lama dibanding 1 tahun di Venus \n3. Satu - satunya planet yang berotasi searah jarum jam. \nDengan arah rotasi yang berbeda, Matahari di Venus akan terbit dari Barat dan tenggelam di Timur\n 4. Planet kembaran Bumi.Ukuran dan komposisinya hampir sama dengan Bumi hanya saja atmosfer Venus didominasi asam sulfur beracun ", {
                font: font,
                size: 1,
                height: 1,
            }
        )

        let textMeshP = new THREE.Mesh(geoP, [
            new THREE.MeshPhongMaterial({ color: 0x000000 }),
            new THREE.MeshPhongMaterial({ color: 0x808080 })
        ])

        textMeshP.castShadow = true
        textMeshP.position.y = VenusMesh.position.y - 5
        textMeshP.position.z = VenusMesh.position.z
        textMeshP.position.x = VenusMesh.position.x + 10
        scene.add(textMeshP)
    })
}

function CreateLight() {
    const light = new THREE.AmbientLight(0xFFFFFF, 1);
    scene.add(light);
}

function animate() {
    requestAnimationFrame(animate);
    control.update();
    renderer.render(scene, camera);
}

window.onload = () => {
    Venus()
    CreateLight();
    //PlanetListener(); //gk bisa
    animate();
}