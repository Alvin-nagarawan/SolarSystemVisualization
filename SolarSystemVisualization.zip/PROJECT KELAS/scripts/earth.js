import * as THREE from '../three.js-master/build/three.module.js'
import * as THREE_Font from '../three.js-master/examples/jsm/loaders/FontLoader.js'
import * as THREE_TextGeo from '../three.js-master/examples/jsm/geometries/TextGeometry.js'
import { OrbitControls } from '../three.js-master/examples/jsm/controls/OrbitControls.js'

let w = window.innerWidth;
let h = window.innerHeight;
let aspect = w / h;
let scene = new THREE.Scene();

let camera = new THREE.PerspectiveCamera(45, aspect, 0.1, 1000);
camera.position.set(0, 0, 128);
camera.lookAt(new THREE.Vector3(0, 0, 0));

let renderer = new THREE.WebGLRenderer({ antialias: true });
renderer.setSize(w, h);
renderer.setClearColor(0xf1f1f1);
renderer.shadowMap.type = THREE.PCFShadowMap;
renderer.shadowMap.enabled = true;

let control = new OrbitControls(camera, renderer.domElement);

let EarthMesh

document.body.appendChild(renderer.domElement);

function Earth() {
    const EarthGeo = new THREE.SphereGeometry(6);
    const EarthText = new THREE.TextureLoader().load("./assets/planet/earth.jpeg");
    const EarthMat = new THREE.MeshBasicMaterial({ map: EarthText });
    EarthMesh = new THREE.Mesh(EarthGeo, EarthMat);
    EarthMesh.receiveShadow = true;
    EarthMesh.name = "earth"
    EarthMesh.position.set(-20, 0, 0)

    scene.add(EarthMesh);

    let loader = new THREE_Font.FontLoader()
    loader.load('../fonts/Roboto_Regular.json', function(font) {
        const geoH1 = new THREE_TextGeo.TextGeometry(
            'Planet Earth ', {
                font: font,
                size: 3,
                height: 2,
            }
        )

        let textMeshH1 = new THREE.Mesh(geoH1, [
            new THREE.MeshPhongMaterial({ color: 0x000000 }),
            new THREE.MeshPhongMaterial({ color: 0x808080 })
        ])

        textMeshH1.castShadow = true
        textMeshH1.position.y = EarthMesh.position.y
        textMeshH1.position.z = EarthMesh.position.z
        textMeshH1.position.x = EarthMesh.position.x + 10
        scene.add(textMeshH1)

        const geoP = new THREE_TextGeo.TextGeometry(
            "1. Bumi disebut planet air. 70% dari permukaan bumi ditutupi oleh lautan\n2. Manusia tidak mempengaruhi massa berat bumi\n3. Planet terpadat di tata surya. Kepadatan rata-rata Bumi adalah 5,52 gram / cm3\n4. Manusia hanya tinggal di 1% bagian dari keseluruhan bumi", {
                font: font,
                size: 1,
                height: 1,
            }
        )

        let textMeshP = new THREE.Mesh(geoP, [
            new THREE.MeshPhongMaterial({ color: 0x000000 }),
            new THREE.MeshPhongMaterial({ color: 0x808080 })
        ])

        textMeshP.castShadow = true
        textMeshP.position.y = EarthMesh.position.y - 5
        textMeshP.position.z = EarthMesh.position.z
        textMeshP.position.x = EarthMesh.position.x + 10
        scene.add(textMeshP)
    })
}

function CreateLight() {
    const light = new THREE.AmbientLight(0xFFFFFF, 1);
    scene.add(light);
}

function rotateGlobe() {
    requestAnimationFrame(animate);
    EarthMesh.rotation.x += 20
}

function animate() {
    requestAnimationFrame(animate);
    control.update();
    renderer.render(scene, camera);
}

window.onload = () => {
    Earth()
    CreateLight();
    //PlanetListener(); //gk bisa
    animate();
}