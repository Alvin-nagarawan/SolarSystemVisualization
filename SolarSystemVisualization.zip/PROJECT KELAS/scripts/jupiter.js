import * as THREE from '../three.js-master/build/three.module.js'
import * as THREE_Font from '../three.js-master/examples/jsm/loaders/FontLoader.js'
import * as THREE_TextGeo from '../three.js-master/examples/jsm/geometries/TextGeometry.js'
import { OrbitControls } from '../three.js-master/examples/jsm/controls/OrbitControls.js'

let w = window.innerWidth;
let h = window.innerHeight;
let aspect = w / h;
let scene = new THREE.Scene();

let camera = new THREE.PerspectiveCamera(45, aspect, 0.1, 1000);
camera.position.set(0, 0, 128);
camera.lookAt(new THREE.Vector3(0, 0, 0));

let renderer = new THREE.WebGLRenderer({ antialias: true });
renderer.setSize(w, h);
renderer.setClearColor(0xf1f1f1);
renderer.shadowMap.type = THREE.PCFShadowMap;
renderer.shadowMap.enabled = true;

let control = new OrbitControls(camera, renderer.domElement);

document.body.appendChild(renderer.domElement);

function Jupiter() {
    const JupiterGeo = new THREE.SphereGeometry(4);
    const JupiterText = new THREE.TextureLoader().load("./assets/planet/jupiter.jpeg");
    const JupiterMat = new THREE.MeshBasicMaterial({ map: JupiterText });
    const JupiterMesh = new THREE.Mesh(JupiterGeo, JupiterMat);
    JupiterMesh.receiveShadow = true;
    JupiterMesh.name = "jupiter"
    JupiterMesh.position.set(-20, 0, 0)
    scene.add(JupiterMesh);

    let loader = new THREE_Font.FontLoader()
    loader.load('../fonts/Roboto_Regular.json', function(font) {
        const geoH1 = new THREE_TextGeo.TextGeometry(
            'Planet Jupiter ', {
                font: font,
                size: 3,
                height: 2,
            }
        )

        let textMeshH1 = new THREE.Mesh(geoH1, [
            new THREE.MeshPhongMaterial({ color: 0x000000 }),
            new THREE.MeshPhongMaterial({ color: 0x808080 })
        ])

        textMeshH1.castShadow = true
        textMeshH1.position.y = JupiterMesh.position.y
        textMeshH1.position.z = JupiterMesh.position.z
        textMeshH1.position.x = JupiterMesh.position.x + 10
        scene.add(textMeshH1)

        const geoP = new THREE_TextGeo.TextGeometry(
            "1. Planet terbesar di Tata Surya\n2.Planet dengan 1 hari paling pendek di Tata Surya, yaitu hanya sekitar 9 jam \n3. Memiliki fenomena The Great Red Spot yang merupakan fenomena antisiklon \ndi mana terjadi perputaran angin badai yang sangat besar dan persisten \n4. Dijuluki planet pelindung Bumi.Jupiter memiliki gaya garvitas terkuat di \nTata Surya sehingga mampu merusak komet, meteorit dan asteroid yang melintas di dekatnya termasuk Bumi", {
                font: font,
                size: 1,
                height: 1,
            }

        )

        let textMeshP = new THREE.Mesh(geoP, [
            new THREE.MeshPhongMaterial({ color: 0x000000 }),
            new THREE.MeshPhongMaterial({ color: 0x808080 })
        ])

        textMeshP.castShadow = true
        textMeshP.position.y = JupiterMesh.position.y - 5
        textMeshP.position.z = JupiterMesh.position.z
        textMeshP.position.x = JupiterMesh.position.x + 10
        scene.add(textMeshP)
    })
}

function CreateLight() {
    const light = new THREE.AmbientLight(0xFFFFFF, 1);
    scene.add(light);
}

function animate() {
    requestAnimationFrame(animate);
    control.update();
    renderer.render(scene, camera);
}

window.onload = () => {
    Jupiter();
    CreateLight();
    //PlanetListener(); //gk bisa
    animate();
}