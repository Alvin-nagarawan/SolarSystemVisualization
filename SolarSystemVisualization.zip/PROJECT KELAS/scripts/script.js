import * as THREE from '../three.js-master/build/three.module.js'
import { OrbitControls } from '../three.js-master/examples/jsm/controls/OrbitControls.js'
import { GLTFLoader } from '../three.js-master/examples/jsm/loaders/GLTFLoader.js'
import { FontLoader } from '../three.js-master/examples/jsm/loaders/FontLoader.js'
import { TextGeometry } from '../three.js-master/examples/jsm/geometries/TextGeometry.js'
//import THREEx from './threex.domevents-master/threex.domevents.js'
//import './threex.domevents.js'
//import * as THREEx from './threex.domevents-master/threex.domevents.js'
//import {gsap} from './gsap-public/minified/gsap.min.js'


let w = window.innerWidth;
let h = window.innerHeight;
let aspect = w / h;
let scene = new THREE.Scene();

let camera = new THREE.PerspectiveCamera(45, aspect, 0.1, 1000);
camera.position.set(0, 64, 128);
camera.lookAt(new THREE.Vector3(0, 0, 0));

let renderer = new THREE.WebGLRenderer({ antialias: true });
renderer.setSize(w, h);
renderer.setClearColor(0x121212);
renderer.shadowMap.type = THREE.PCFShadowMap;
renderer.shadowMap.enabled = true;
document.body.appendChild(renderer.domElement);

let control = new OrbitControls(camera, renderer.domElement);

let rayCast = new THREE.Raycaster()
let mouse = {}

addEventListener("mousedown", (e) => {
    mouse.x = (e.clientX / w) * 2 - 1
    mouse.y = (e.clientY / h) * -2 + 1
        //console.log(mouse)

    rayCast.setFromCamera(mouse, camera)
    let items = rayCast.intersectObjects(scene.children)

    items.forEach((i) => {
        if (i.object.name === "mercury") {
            window.open("Mercury.html", "_self")
        } else if (i.object.name === "venus") {
            window.open("Venus.html", "_self")
        } else if (i.object.name === "earth") {
            window.open("Earth.html", "_self")
        } else if (i.object.name === "mars") {
            window.open("Mars.html", "_self")
        } else if (i.object.name === "jupiter") {
            window.open("Jupiter.html", "_self")
        } else if (i.object.name === "saturn") {
            window.open("Saturn.html", "_self")
        } else if (i.object.name === "uranus") {
            window.open("Uranus.html", "_self")
        } else if (i.object.name === "neptune") {
            window.open("Neptune.html", "_self")
        } else if (i.object.name === "sun") {
            window.open("Sun.html", "_self")
        }

    })
})

function MainSolarSystem() {
    const SolarSystem = new THREE.Group();
    const MercurySystem = new THREE.Group();
    const VenusSystem = new THREE.Group();
    const EarthSystem = new THREE.Group();
    const MarsSystem = new THREE.Group();
    const JupiterSystem = new THREE.Group();
    const SaturnSystem = new THREE.Group();
    const UranusSystem = new THREE.Group();
    const NeptuneSystem = new THREE.Group();

    function Sun() {
        const SunGeo = new THREE.SphereGeometry(12.5);
        const SunText = new THREE.TextureLoader().load("./assets/planet/sun.jpeg");
        const SunMat = new THREE.MeshBasicMaterial({ map: SunText });
        const SunMesh = new THREE.Mesh(SunGeo, SunMat);
        SunMesh.position.set = (0, 0, 0);
        SunMesh.castShadow = true;
        SunMesh.receiveShadow = true;
        SunMesh.name = "sun"
        SolarSystem.add(SunMesh);

        //scene.add(SunMesh);
    }

    function Mercury() {
        const MercuryGeo = new THREE.SphereGeometry(2);
        const MercuryText = new THREE.TextureLoader().load("./assets/planet/mercury.jpeg");
        const MercuryMat = new THREE.MeshBasicMaterial({ map: MercuryText });
        const MercuryMesh = new THREE.Mesh(MercuryGeo, MercuryMat);
        MercuryMesh.position.x = 16;
        MercuryMesh.receiveShadow = true;
        MercuryMesh.name = "mercury"
        MercurySystem.add(MercuryMesh);
        SolarSystem.add(MercurySystem);
    }

    function Venus() {
        const VenusGeo = new THREE.SphereGeometry(3.5);
        const VenusText = new THREE.TextureLoader().load("./assets/planet/venus.jpeg");
        const VenusMat = new THREE.MeshBasicMaterial({ map: VenusText });
        const VenusMesh = new THREE.Mesh(VenusGeo, VenusMat);
        VenusMesh.position.x = 32;
        VenusMesh.name = "venus"
        VenusSystem.receiveShadow = true;
        VenusSystem.add(VenusMesh);
        SolarSystem.add(VenusSystem);
    }

    function Earth() {
        const EarthGeo = new THREE.SphereGeometry(4);
        const EarthText = new THREE.TextureLoader().load("./assets/planet/earth.jpeg");
        const EarthMat = new THREE.MeshBasicMaterial({ map: EarthText });
        const EarthMesh = new THREE.Mesh(EarthGeo, EarthMat);
        EarthMesh.position.x = 48;
        EarthMesh.receiveShadow = true;
        EarthMesh.name = "earth"
        EarthSystem.add(EarthMesh);
        SolarSystem.add(EarthSystem);
    }

    function Mars() {
        const MarsGeo = new THREE.SphereGeometry(3);
        const MarsText = new THREE.TextureLoader().load("./assets/planet/mars.jpeg");
        const MarsMat = new THREE.MeshBasicMaterial({ map: MarsText });
        const MarsMesh = new THREE.Mesh(MarsGeo, MarsMat);
        MarsMesh.position.x = 64;
        MarsMesh.name = "mars"
        MarsSystem.receiveShadow = true;
        MarsSystem.add(MarsMesh);
        SolarSystem.add(MarsSystem);
    }

    function Jupiter() {
        const JupiterGeo = new THREE.SphereGeometry(8);
        const JupiterText = new THREE.TextureLoader().load("./assets/planet/jupiter.jpeg");
        const JupiterMat = new THREE.MeshBasicMaterial({ map: JupiterText });
        const JupiterMesh = new THREE.Mesh(JupiterGeo, JupiterMat);
        JupiterMesh.position.x = 80;
        JupiterMesh.name = "jupiter"
        JupiterSystem.receiveShadow = true;
        JupiterSystem.add(JupiterMesh);
        SolarSystem.add(JupiterSystem);
    }

    function Saturn() {
        const SaturnGeo = new THREE.SphereGeometry(7);
        const SaturnText = new THREE.TextureLoader().load("./assets/planet/saturn.jpeg");
        const SaturnMat = new THREE.MeshBasicMaterial({ map: SaturnText });
        const SaturnMesh = new THREE.Mesh(SaturnGeo, SaturnMat);
        SaturnMesh.position.x = 96;
        SaturnMesh.name = "saturn"
        SaturnMesh.receiveShadow = true;
        SaturnSystem.add(SaturnMesh);
        SolarSystem.add(SaturnSystem);
    }

    function Uranus() {
        const UranusGeo = new THREE.SphereGeometry(4.5);
        const UranusText = new THREE.TextureLoader().load("./assets/planet/uranus.jpeg");
        const UranusMat = new THREE.MeshBasicMaterial({ map: UranusText });
        const UranusMesh = new THREE.Mesh(UranusGeo, UranusMat);
        UranusMesh.position.x = 112;
        UranusMesh.name = "uranus"
        UranusSystem.receiveShadow = true;
        UranusSystem.add(UranusMesh);
        SolarSystem.add(UranusSystem);
    }

    function Neptune() {
        const NeptuneGeo = new THREE.SphereGeometry(3.5);
        const NeptuneText = new THREE.TextureLoader().load("./assets/planet/neptune.jpeg");
        const NeptuneMat = new THREE.MeshBasicMaterial({ map: NeptuneText });
        const NeptuneMesh = new THREE.Mesh(NeptuneGeo, NeptuneMat);
        NeptuneMesh.position.x = 128;
        NeptuneMesh.name = "neptune"
        NeptuneSystem.receiveShadow = true;
        NeptuneSystem.add(NeptuneMesh);
        SolarSystem.add(NeptuneSystem);
    }

    Sun();
    Mercury();
    Venus();
    Earth();
    Mars();
    Jupiter();
    Saturn();
    Uranus();
    Neptune();

    const one_year_earth = Math.PI * 3 * (1.5 / 60) * (1.5 / 60);

    function SolarAnim() {
        requestAnimationFrame(SolarAnim);
        SolarSystem.rotation.y += 0.001;
        MercurySystem.rotation.y += one_year_earth * 4;
        VenusSystem.rotation.y += one_year_earth * 2;
        EarthSystem.rotation.y += one_year_earth;
        MarsSystem.rotation.y += one_year_earth * 0.5;
        JupiterSystem.rotation.y += one_year_earth * 0.25;
        SaturnSystem.rotation.y += one_year_earth * 0.125;
        UranusSystem.rotation.y += one_year_earth * 0.0625;
        NeptuneSystem.rotation.y += one_year_earth * 0.03125;
    }
    SolarAnim();


    scene.add(SolarSystem);


}

function CreateLight() {
    const light = new THREE.AmbientLight(0xFFFFFF, 1);
    scene.add(light);
}

function CreateSkyBox() {

}

function animate() {
    requestAnimationFrame(animate);
    control.update();
    renderer.render(scene, camera);
}

// function PlanetListener() {
//     var domEvents = new THREEx.DomEvents(camera, renderer.domElement);
//     //let domEvent = THREEx.DomEvents(camera, renderer.domElement); 

//     let objectClicked = false;

//     domEvents.addEventListener(SunMesh, 'click', event => {
//         SunText.TextureLoader.load(test.jpg);
//     });

//     domEvents.addEventListener(MercuryMesh, 'click', event => {
//         objectClicked = true;
//         console.log(objectClicked);
//     }); // Pencet mercury di console nya jadi true gak? belum di mulai classnya

//     // domEvent.addEventListener(VenusMesh, 'click', event=>{
// }



window.onload = () => {
    MainSolarSystem();
    CreateLight();
    //PlanetListener(); //gk bisa
    animate();
}