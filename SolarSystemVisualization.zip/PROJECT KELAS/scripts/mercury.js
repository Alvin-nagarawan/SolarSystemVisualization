import * as THREE from '../three.js-master/build/three.module.js'
import * as THREE_Font from '../three.js-master/examples/jsm/loaders/FontLoader.js'
import * as THREE_TextGeo from '../three.js-master/examples/jsm/geometries/TextGeometry.js'
import { OrbitControls } from '../three.js-master/examples/jsm/controls/OrbitControls.js'

let w = window.innerWidth;
let h = window.innerHeight;
let aspect = w / h;
let scene = new THREE.Scene();

let camera = new THREE.PerspectiveCamera(45, aspect, 0.1, 1000);
camera.position.set(0, 0, 128);
camera.lookAt(new THREE.Vector3(0, 0, 0));

let renderer = new THREE.WebGLRenderer({ antialias: true });
renderer.setSize(w, h);
renderer.setClearColor(0xf1f1f1);
renderer.shadowMap.type = THREE.PCFShadowMap;
renderer.shadowMap.enabled = true;

let control = new OrbitControls(camera, renderer.domElement);


document.body.appendChild(renderer.domElement);

function Mercury() {
    const MercuryGeo = new THREE.SphereGeometry(2);
    const MercuryText = new THREE.TextureLoader().load("./assets/planet/mercury.jpeg");
    const MercuryMat = new THREE.MeshBasicMaterial({ map: MercuryText });
    const MercuryMesh = new THREE.Mesh(MercuryGeo, MercuryMat);
    MercuryMesh.position.x = 16;
    MercuryMesh.receiveShadow = true;
    MercuryMesh.name = "mercury"
    MercuryMesh.position.set(-20, 0, 0)
    scene.add(MercuryMesh);

    let loader = new THREE_Font.FontLoader()
    loader.load('../fonts/Roboto_Regular.json', function(font) {
        const geoH1 = new THREE_TextGeo.TextGeometry(
            'Planet Mercury ', {
                font: font,
                size: 3,
                height: 2,
            }
        )

        let textMeshH1 = new THREE.Mesh(geoH1, [
            new THREE.MeshPhongMaterial({ color: 0x000000 }),
            new THREE.MeshPhongMaterial({ color: 0x808080 })
        ])

        textMeshH1.castShadow = true
        textMeshH1.position.y = MercuryMesh.position.y
        textMeshH1.position.z = MercuryMesh.position.z
        textMeshH1.position.x = MercuryMesh.position.x + 10
        scene.add(textMeshH1)

        const geoP = new THREE_TextGeo.TextGeometry(
            "1. Planet paling dekat dengan matahari\n2. Planet terkecil di Tata Surya dan setiap harinya semakin mengecil\n 3. Periode 1 hari di planet ini lebih lama dibanding periode 1 tahunnya \n4. Tidak memiliki satelit ", {
                font: font,
                size: 1,
                height: 1,
            }
        )

        let textMeshP = new THREE.Mesh(geoP, [
            new THREE.MeshPhongMaterial({ color: 0x000000 }),
            new THREE.MeshPhongMaterial({ color: 0x808080 })
        ])

        textMeshP.castShadow = true
        textMeshP.position.y = MercuryMesh.position.y - 5
        textMeshP.position.z = MercuryMesh.position.z
        textMeshP.position.x = MercuryMesh.position.x + 10
        scene.add(textMeshP)
    })
}

function CreateLight() {
    const light = new THREE.AmbientLight(0xFFFFFF, 1);
    scene.add(light);
}

function animate() {
    requestAnimationFrame(animate);
    control.update();
    renderer.render(scene, camera);
}

window.onload = () => {
    Mercury()
    CreateLight();
    //PlanetListener(); //gk bisa
    animate();
}