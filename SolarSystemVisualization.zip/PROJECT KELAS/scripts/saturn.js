import * as THREE from '../three.js-master/build/three.module.js'
import * as THREE_Font from '../three.js-master/examples/jsm/loaders/FontLoader.js'
import * as THREE_TextGeo from '../three.js-master/examples/jsm/geometries/TextGeometry.js'
import { OrbitControls } from '../three.js-master/examples/jsm/controls/OrbitControls.js'

let w = window.innerWidth;
let h = window.innerHeight;
let aspect = w / h;
let scene = new THREE.Scene();

let camera = new THREE.PerspectiveCamera(45, aspect, 0.1, 1000);
camera.position.set(0, 0, 128);
camera.lookAt(new THREE.Vector3(0, 0, 0));

let renderer = new THREE.WebGLRenderer({ antialias: true });
renderer.setSize(w, h);
renderer.setClearColor(0xf1f1f1);
renderer.shadowMap.type = THREE.PCFShadowMap;
renderer.shadowMap.enabled = true;

let control = new OrbitControls(camera, renderer.domElement);

document.body.appendChild(renderer.domElement);

function Saturn() {
    const SaturnGeo = new THREE.SphereGeometry(8);
    const SaturnText = new THREE.TextureLoader().load("./assets/planet/saturn.jpeg");
    const SaturnMat = new THREE.MeshBasicMaterial({ map: SaturnText });
    const SaturnMesh = new THREE.Mesh(SaturnGeo, SaturnMat);
    SaturnMesh.receiveShadow = true;
    SaturnMesh.name = "saturn"
    SaturnMesh.position.set(-20, 0, 0)
    scene.add(SaturnMesh);

    let loader = new THREE_Font.FontLoader()
    loader.load('../fonts/Roboto_Regular.json', function(font) {
        const geoH1 = new THREE_TextGeo.TextGeometry(
            'Planet Saturn ', {
                font: font,
                size: 3,
                height: 2,
            }
        )

        let textMeshH1 = new THREE.Mesh(geoH1, [
            new THREE.MeshPhongMaterial({ color: 0x000000 }),
            new THREE.MeshPhongMaterial({ color: 0x808080 })
        ])

        textMeshH1.castShadow = true
        textMeshH1.position.y = SaturnMesh.position.y
        textMeshH1.position.z = SaturnMesh.position.z
        textMeshH1.position.x = SaturnMesh.position.x + 10
        scene.add(textMeshH1)

        const geoP = new THREE_TextGeo.TextGeometry(
            "1. Disebut planet cincin karena mempunyai cincin yang indah pada porosnya.\n2. Bobot planet Saturnus sangat ringan. Apabila ada danau yang diletakkan di bawah Saturnus, Saturnus dapat tetap mengapung di atasnya.\n3. Planet kedua terbesar di Tata Surya.\n4. Planet dengan kecepatan angin tercepat mencapai 1800 km/jam.", {
                font: font,
                size: 1,
                height: 1,
            }
        )

        let textMeshP = new THREE.Mesh(geoP, [
            new THREE.MeshPhongMaterial({ color: 0x000000 }),
            new THREE.MeshPhongMaterial({ color: 0x808080 })
        ])

        textMeshP.castShadow = true
        textMeshP.position.y = SaturnMesh.position.y - 5
        textMeshP.position.z = SaturnMesh.position.z
        textMeshP.position.x = SaturnMesh.position.x + 10
        scene.add(textMeshP)
    })
}

function CreateLight() {
    const light = new THREE.AmbientLight(0xFFFFFF, 1);
    scene.add(light);
}

function animate() {
    requestAnimationFrame(animate);
    control.update();
    renderer.render(scene, camera);
}

window.onload = () => {
    Saturn();
    CreateLight();
    //PlanetListener(); //gk bisa
    animate();
}